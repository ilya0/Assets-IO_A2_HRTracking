var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var path = require('path');
var rp = require('request-promise');
var fs = require('fs');
var obj;

global.__basedir = __dirname;
var fileName = __basedir + '/uploads/'




app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '/')));
app.use(bodyParser.json());

app.use(function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

app.get('/', function (req, res) {

    res.sendFile(__dirname + "/index.html");
});




//get nordstorm data for a barcode number
app.get('/api/nordStormProductDetail', (req, res) => {

    console.log("connected toooo")
    var productid = req.query.productId
   
  console.log(productid)
   let rawdata = fs.readFileSync('./nordstorm_db_data/productDetailsHistory.json');  
   let productHistory = JSON.parse(rawdata);  
   productHistory = productHistory.products
  for(product in productHistory){
      console.log(product)
      if(productHistory[product].ProductId==productid){
          console.log('true')
          res.json(productHistory[product])
      }
  }
   
        

    
});



app.get('/api/getHistoryForProduct', (req, res) => {
console.log(req.query.productid)

    const options = {
        method: 'POST',
        uri: 'http://129.213.54.206:5123/bcsgw/rest/v1/transaction/query',
        headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',

        },
        body: {
            "channel":"directororderer",
            "chaincode":"chain4",
            "method":"getHistoryForProduct",
            "args":[ req.query.productid],
            "chaincodeVer":"v1"
            },
        json: true,

    }
     
    rp(options)
    .then(function (parsedBody) {
        // POST succeeded...
        console.log('result-----',parsedBody.result.payload)
        res.json(JSON.parse(parsedBody.result.payload))
    })
    .catch(function (err) {
        // POST failed...
        res.json(err)
    });
})


app.get('/api/readProduct',(req,res) =>{

    const options = {
        method: 'POST',
        uri: 'http://129.213.54.206:5123/bcsgw/rest/v1/transaction/query',
        headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',

        },
        body: {
            "channel":"directororderer",
            "chaincode":"chain4",
            "method":"readProduct",
            "args":[ req.query.productid],
            "chaincodeVer":"v1"
            }
            ,
        json: true,

    }
     
    rp(options)
        .then(function (parsedBody) {
            // POST succeeded...
            console.log('result-----',parsedBody.result.payload)
            res.json(JSON.parse(parsedBody.result.payload))
        })
        .catch(function (err) {
            // POST failed...
            res.json(err)
        });

})


app.post('/api/readProductHistory',(req, res) =>{
    var completed_requests = 0;
    console.log(req.body)
    var productArray = req.body.productArray;
    console.log('array --',productArray)
    var productHistory = [ ];
    for (j = 0; j < productArray.length; j++) {
       var    prodId = productArray[j].prodid
       console.log(prodId) ;
    var productHistorycallback = function (form, index) {
console.log('form',form)
       
    const options = {
        method: 'POST',
        uri: 'http://129.213.54.206:5123/bcsgw/rest/v1/transaction/query',
        headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',

        },
        body: {
            "channel":"directororderer",
            "chaincode":"chain4",
            "method":"readProduct",
            "args":[ form ],
            "chaincodeVer":"v1"
            }
            ,
        json: true,

    }

    rp(options, function (err, httpResponse, parsedBody) {
        // options = options; Superfluous
        if (!err) {
console.log(parsedBody.result.payload)
            completed_requests += 1;
            var prodDetails = JSON.parse(parsedBody.result.payload);
            productHistory.push(    prodDetails)

            if (completed_requests == productArray.length) {
                console.log('<----------data pushed to AMCE successfully---------->')
console.log(productHistory)
                res.json(productHistory)
             }
            else {
                //  console.log('func()---->loop ', j, 'completed')
                //return;
            }
        }
        else {
            console.log('<----------Data insertion to AMCE failed---------->')
            res.status(500).json({
                error: 'File is not uploaded successfully!',
            })
        }
    });
  
    
    }
    //  console.log('Iterating loop index = ', j)
    productHistorycallback(prodId, j);
}

})


app.post('/api/transferProduct', (req,res) =>{
  

    const options = {
        method: 'POST',
        uri: 'http://129.213.54.206:5123/bcsgw/rest/v1/transaction/invocation',
        headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',

        },
        body: {
            "channel":"directororderer",
            "chaincode":"chain4",
            "method":"transferProduct",
            "args": req.query.id, 
            "chaincodeVer":"v1"
            }
            ,
        json: true,

    }
    console.log(options)
     
    rp(options)
        .then(function (response) {
            // POST succeeded...
            console.log('result-----',)
            res.json(response)
        })
        .catch(function (err) {
            // POST failed...
            res.json(err)
        });

})


var port = process.env.PORT || 8081;
app.listen(port, function () {
    console.log('<----------listening on localhost and ' + port + '---------->')
});
